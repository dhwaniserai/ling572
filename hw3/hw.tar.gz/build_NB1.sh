#!/bin/sh
/nopt/python-3.6/bin/python3 nb_trial2.py $1 $2 $3 $4 $5 $6