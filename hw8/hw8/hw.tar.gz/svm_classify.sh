#!/bin/sh
/nopt/python-3.6/bin/python3 svm_binary.py $1 $2 $3